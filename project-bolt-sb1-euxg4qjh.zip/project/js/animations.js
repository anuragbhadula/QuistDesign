// Animation JavaScript File

// Intersection Observer for scroll animations
const observerOptions = {
  root: null,
  rootMargin: '0px',
  threshold: 0.15
};

// Create an intersection observer for fade-in animations
const fadeObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('fade-in-visible');
      fadeObserver.unobserve(entry.target);
    }
  });
}, observerOptions);

// Create an intersection observer for slide-up animations
const slideObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('slide-up-visible');
      slideObserver.unobserve(entry.target);
    }
  });
}, observerOptions);

// Apply animations to section headers
document.querySelectorAll('.section-header').forEach(header => {
  header.classList.add('fade-in');
  fadeObserver.observe(header);
});

// Service cards slide up
document.querySelectorAll('.service-card').forEach((card, index) => {
  card.classList.add('slide-up');
  card.style.transitionDelay = `${index * 0.1}s`;
  slideObserver.observe(card);
});

// USP cards fade in
document.querySelectorAll('.usp-card').forEach((card, index) => {
  card.classList.add('fade-in');
  card.style.transitionDelay = `${index * 0.1}s`;
  fadeObserver.observe(card);
});

// Price cards slide up
document.querySelectorAll('.pricing-card').forEach((card, index) => {
  card.classList.add('slide-up');
  card.style.transitionDelay = `${index * 0.1}s`;
  slideObserver.observe(card);
});

// Portfolio items fade in
document.querySelectorAll('.portfolio-item').forEach((item, index) => {
  item.classList.add('fade-in');
  item.style.transitionDelay = `${index * 0.1}s`;
  fadeObserver.observe(item);
});

// About section elements
document.querySelector('.about-text')?.classList.add('slide-up');
slideObserver.observe(document.querySelector('.about-text'));

document.querySelector('.about-image')?.classList.add('fade-in');
fadeObserver.observe(document.querySelector('.about-image'));

// Contact section elements
document.querySelector('.contact-info')?.classList.add('slide-up');
slideObserver.observe(document.querySelector('.contact-info'));

document.querySelector('.contact-form')?.classList.add('fade-in');
fadeObserver.observe(document.querySelector('.contact-form'));

// Add CSS for animations
const style = document.createElement('style');
style.textContent = `
  /* Animation classes */
  .fade-in {
    opacity: 0;
    transition: opacity 0.8s ease-out;
  }
  
  .fade-in-visible {
    opacity: 1;
  }
  
  .slide-up {
    opacity: 0;
    transform: translateY(40px);
    transition: opacity 0.6s ease-out, transform 0.8s ease-out;
  }
  
  .slide-up-visible {
    opacity: 1;
    transform: translateY(0);
  }
`;
document.head.appendChild(style);

// Hero animations
document.addEventListener('DOMContentLoaded', () => {
  // Hero animations are handled in the CSS with the .animate-on-load class
  // This is just to ensure all animations are properly initialized
  setTimeout(() => {
    document.querySelectorAll('.animate-on-load').forEach(element => {
      element.style.opacity = '1';
      element.style.transform = 'translateY(0)';
    });
  }, 100);
});

// Hover effects for UI elements
const addHoverEffects = () => {
  // Service icon pulse effect
  document.querySelectorAll('.service-icon').forEach(icon => {
    icon.addEventListener('mouseenter', () => {
      icon.style.transform = 'scale(1.1)';
      icon.style.boxShadow = '0 0 20px rgba(94, 23, 235, 0.4)';
    });
    
    icon.addEventListener('mouseleave', () => {
      icon.style.transform = 'scale(1)';
      icon.style.boxShadow = 'none';
    });
  });
  
  // Portfolio item hover effect enhancement
  document.querySelectorAll('.portfolio-item').forEach(item => {
    item.addEventListener('mouseenter', () => {
      const overlay = item.querySelector('.portfolio-overlay');
      overlay.style.backdropFilter = 'blur(3px)';
    });
    
    item.addEventListener('mouseleave', () => {
      const overlay = item.querySelector('.portfolio-overlay');
      overlay.style.backdropFilter = 'none';
    });
  });
};

// Initialize hover effects
addHoverEffects();